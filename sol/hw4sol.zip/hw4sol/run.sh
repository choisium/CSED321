#!/bin/bash

rm -f result.txt
touch result.txt

HW_NUM=4
FILE=../id.txt
DIR=../hw"$HW_NUM"

while read id; do
    file=$DIR/$id.ml
    if [ -f "$file" ]
    then
        rm -f hw"$HW_NUM"test *.annot *.aux *.log *.cm[iox] *.dvi run.ml eval.ml .depend

        cp $file eval.ml

        # test compile
        touch .depend
        ocamldep eval.ml eval.mli > .depend
        ocamlc -thread -c uml.ml -o uml.cmo

        ocamlyacc parser.mly
        ocamlc -c parser.mli
        ocamlc -c parser.ml
        ocamllex lexer.mll
        ocamlc -c lexer.ml

        ocamlc -thread -c parser.ml -o parser.cmo
        ocamlc -thread -c lexer.ml -o lexer.cmo
        ocamlc -thread -c inout.ml -o inout.cmo

        ocamlc -thread -c eval.mli -o eval.cmi
        ocamlc -thread -c eval.ml -o eval.cmo

        if [ -f "eval.cmo" ]
        then
            # run test functor
            touch run.ml
            echo "module H$id = Evaltest.F (Eval) (struct let name = \""$id"\" end);;" > run.ml

            ocamlc -thread -c evalsol.ml -o evalsol.cmo
            ocamlc -thread -c loop.ml -o loop.cmo
            ocamlc -thread -c evaltest.ml -o evaltest.cmo
            ocamlc -thread -c run.ml -o run.cmo
            ocamlc -thread -o hw"$HW_NUM"test unix.cma threads.cma uml.cmo parser.cmo lexer.cmo inout.cmo eval.cmo evalsol.cmo loop.cmo evaltest.cmo run.cmo

            ./hw"$HW_NUM"test >> result.txt

            # clean
            rm -f hw"$HW_NUM"test *.annot *.aux *.log *.cm[iox] *.dvi run.ml eval.ml .depend parser.mli parser.ml lexer.ml
        else
            echo $id" 0 : cannot compile" >> result.txt
        fi
    else
        echo $id" 0 : file not found "$file >> result.txt
    fi
done < $FILE

sed -i '/Test score/d' result.txt
