#!/bin/bash

rm -f result.txt
touch result.txt

HW_NUM=1
FILE=../id.txt
DIR=../hw$HW_NUM        

while read id; do
    file=$DIR/$id.ml
    if [ -f "$file" ]
    then    
        rm -f $id.ml $id.mli .depend run.ml
        
        cp $file $id.ml
        cp hw1.mli $id.mli
        
        # test compile
        touch .depend
        ocamldep $id.ml $id.mli > .depend
        ocamlc -thread -c $id.mli -o $id.cmi
        ocamlc -thread -c $id.ml -o $id.cmo     
        
        if [ -f "$id.cmo" ]
        then
            # run test functor
            touch run.ml
            module=$(echo -e "$id" | sed -r 's/\<./\U&/g') # upcase first letter
            echo "module H$id = Hw1test.F ("$module") (struct let name = \""$id"\" end);;" > run.ml
            
            ocamlc -thread -c hw1.mli -o hw1.cmi
            ocamlc -thread -c hw1.ml -o hw1.cmo
            ocamlc -thread -c hw1sol.ml -o hw1sol.cmo
            ocamlc -thread -c hw1test.ml -o hw1test.cmo
            ocamlc -thread -c run.ml -o run.cmo
            ocamlc -thread -o hw1test unix.cma threads.cma $id.cmo hw1.cmo hw1sol.cmo hw1test.cmo run.cmo
            
            ./hw1test >> result.txt
            
            # clean
            rm -f hw1test *.annot *.aux *.log *.cm[iox] *.dvi run.ml $id.ml $id.mli .depend
        else
            echo $id" 0 : cannot compile" >> result.txt
        fi
    else
        echo $id" 0 : file not found "$file >> result.txt
    fi
done < $FILE

sed -i '/Test score/d' result.txt
