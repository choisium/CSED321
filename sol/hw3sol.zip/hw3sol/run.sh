#!/bin/bash

rm -f result.txt
touch result.txt

HW_NUM=3
FILE=../id.txt
DIR=../hw"$HW_NUM"

while read id; do
    file=$DIR/$id.ml
    if [ -f "$file" ]
    then
		rm -f hw"$HW_NUM"test *.annot *.aux *.log *.cm[iox] *.dvi run.ml $id.ml $id.mli .depend

        cp $file $id.ml
        cp hw"$HW_NUM".mli $id.mli

        # test compile
        touch .depend
        ocamldep $id.ml $id.mli > .depend
        ocamlc -thread -c common.ml -o common.cmo
        ocamlc -thread -c $id.mli -o $id.cmi
        ocamlc -thread -c $id.ml -o $id.cmo

        if [ -f "$id.cmo" ]
        then
            # run test functor
            touch run.ml
            module=$(echo -e "$id" | sed -r 's/\<./\U&/g') # upcase first letter
            echo "module H$id = Hw"$HW_NUM"test.F ("$module") (struct let name = \""$id"\" end);;" > run.ml

            ocamlc -thread -c hw"$HW_NUM".mli -o hw"$HW_NUM".cmi
            ocamlc -thread -c hw"$HW_NUM".ml -o hw"$HW_NUM".cmo
            ocamlc -thread -c hw"$HW_NUM"sol.ml -o hw"$HW_NUM"sol.cmo
            ocamlc -thread -c hw"$HW_NUM"test.ml -o hw"$HW_NUM"test.cmo
            ocamlc -thread -c run.ml -o run.cmo
            ocamlc -thread -o hw"$HW_NUM"test unix.cma threads.cma common.cmo $id.cmo hw"$HW_NUM".cmo hw"$HW_NUM"sol.cmo hw"$HW_NUM"test.cmo run.cmo

            ./hw"$HW_NUM"test >> result.txt

            # clean
            rm -f hw"$HW_NUM"test *.annot *.aux *.log *.cm[iox] *.dvi run.ml $id.ml $id.mli .depend
        else
            echo $id" 0 : cannot compile" >> result.txt
        fi
    else
        echo $id" 0 : file not found "$file >> result.txt
    fi
done < $FILE

sed -i '/Test score/d' result.txt
