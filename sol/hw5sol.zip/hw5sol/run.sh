#!/bin/bash

rm -f result.txt
touch result.txt

HW_NUM=5
FILE=../id.txt
DIR=../hw"$HW_NUM"



while read id; do
  file=$DIR/$id.ml
  if [ -f "$file" ]
  then
    rm -f hw"$HW_NUM"test *.annot *.aux *.log *.cm[iox] *.dvi run.ml .depend parser.mli parser.ml lexer.ml typing.ml

    cp $file typing.ml

    # test compile
    touch .depend
    ocamlc -thread  -c tml.ml -o tml.cmo
    ocamlyacc parser.mly
    ocamlc -c parser.mli
    ocamlc -c parser.ml
    ocamllex lexer.mll
    ocamlc -c lexer.ml

    ocamlc -thread  -c typing.mli -o typing.cmi
    ocamlc -thread  -c typing.ml -o typing.cmo

    if [ -f "typing.cmo" ]
    then
      # run test functor
      touch run.ml
      echo "module H$id = Typingtest.F (Typing) (struct let name = \""$id"\" end);;" > run.ml

      ocamlc -thread -c typingsol.ml -o typingsol.cmo
      ocamlc -thread -c inout.ml -o inout.cmo
      ocamlc -thread -c eval.ml -o eval.cmo
      ocamlc -thread -c loop.ml -o loop.cmo
      ocamlc -thread -c typingtest.ml -o typingtest.cmo
      ocamlc -thread -c run.ml -o run.cmo
      ocamlc -thread -o hw5test unix.cma threads.cma tml.cmo parser.cmo lexer.cmo typing.cmo typingsol.cmo inout.cmo eval.cmo loop.cmo typingtest.cmo run.cmo

      ./hw"$HW_NUM"test >> result.txt
    else
      echo $id" 0 : cannot compile" >> result.txt
    fi
  else
    echo $id" 0 : file not found "$file >> result.txt
  fi
done < $FILE

rm -f hw"$HW_NUM"test *.annot *.aux *.log *.cm[iox] *.dvi run.ml .depend parser.mli parser.ml lexer.ml typing.ml
sed -i '/Test score/d' result.txt
